# discover-the-world
HTML &amp; CSS implementation of a Figma UI design. Referenced by the portfolio project.
